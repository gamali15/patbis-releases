package com.gamali.patbis

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.*
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        const val GS = '\u001D' // GS (Group Separator) — CK65 AI ayracı
    }

    // ── CİHAZ TESPİTİ ────────────────────────────────────────────────
    private val isHoneywell: Boolean by lazy {
        Build.MANUFACTURER.contains("Honeywell", ignoreCase = true) ||
        Build.BRAND.contains("Honeywell", ignoreCase = true)
    }

    // ── DEPO TANIMI ──────────────────────────────────────────────────
    private val depoList = listOf(
        "33-2019-00419", "33-2019-00422", "33-2019-00425",
        "33-2019-00428", "33-2019-00454", "33-2019-00457"
    )
    private val QR_PREFIX = "GAMALI_DEPO_"
    private val DISPLAY_PREFIX = "ÖZALTIN DEPO "
    private val shortCodeMap = mapOf(
        "419" to "33-2019-00419", "422" to "33-2019-00422",
        "425" to "33-2019-00425", "428" to "33-2019-00428",
        "454" to "33-2019-00454", "457" to "33-2019-00457"
    )

    // ── UI ───────────────────────────────────────────────────────────
    private lateinit var tvCount: TextView
    private lateinit var tvLastScan: TextView
    private lateinit var tvDepoInfo: TextView
    private lateinit var listView: ListView
    private lateinit var btnDepo: Button
    private lateinit var btnCamera: Button
    private lateinit var btnClear: Button
    private lateinit var btnExport: Button
    private lateinit var viewFinder: PreviewView
    private lateinit var statusBar: View

    // ── VERİ ─────────────────────────────────────────────────────────
    private val gs1List = mutableListOf<String>()
    private val otherList = mutableListOf<String>()
    private var secilenDepo = ""
    private var kullaniciAdi = ""
    private var kullanimYeri = ""
    private var sayimTarihi = ""

    private lateinit var adapter: BarcodeListAdapter
    private lateinit var prefs: SharedPreferences
    private var isCameraOpen = false
    private var isDepoScanMode = false
    private var lastCameraScanTime = 0L
    private val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)

    // ── LAUNCHER'LAR ─────────────────────────────────────────────────
    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            uri?.let { saveToFile(it) }
        }
    private val cameraPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Kamera izni gerekli!", Toast.LENGTH_SHORT).show()
        }

    // ── HONEYWELL BROADCAST ──────────────────────────────────────────
    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                var barcode: String? = null
                val keys = arrayOf(
                    "data",
                    "com.honeywell.decode_results",
                    "com.honeywell.intent.extra.SCAN_DATA_STRING"
                )
                for (key in keys) {
                    barcode = it.getStringExtra(key)
                        ?: it.getByteArrayExtra(key)?.let { b -> String(b) }
                    if (barcode != null) break
                }
                if (barcode == null) {
                    it.extras?.keySet()?.forEach { key ->
                        val v = it.extras!!.get(key)
                        if (v is String && v.isNotEmpty() &&
                            !key.contains("version", true) &&
                            !key.contains("source", true)) {
                            barcode = v; return@forEach
                        } else if (v is ByteArray) {
                            barcode = String(v); return@forEach
                        }
                    }
                }
                barcode?.let { b -> processBarcode(b) }
            }
        }
    }

    // ── LIFECYCLE ────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("patbis_prefs", Context.MODE_PRIVATE)

        tvCount    = findViewById(R.id.tvCount)
        tvLastScan = findViewById(R.id.tvLastScan)
        tvDepoInfo = findViewById(R.id.tvDepoInfo)
        listView   = findViewById(R.id.listView)
        btnDepo    = findViewById(R.id.btnDepo)
        btnCamera  = findViewById(R.id.btnCamera)
        btnClear   = findViewById(R.id.btnClear)
        btnExport  = findViewById(R.id.btnExport)
        viewFinder = findViewById(R.id.viewFinder)
        statusBar  = findViewById(R.id.statusBar)

        adapter = BarcodeListAdapter(this, gs1List, otherList)
        listView.adapter = adapter

        checkResumeSayim()

        btnDepo.setOnClickListener { showDepoDialog() }

        btnCamera.setOnClickListener {
            if (isCameraOpen) closeCamera()
            else openCamera(depoMode = false)
        }

        btnClear.setOnClickListener {
            if (gs1List.isEmpty() && otherList.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Listeyi Temizle")
                .setMessage("${gs1List.size + otherList.size} barkod silinecek. Emin misiniz?")
                .setPositiveButton("Evet") { _, _ -> clearAll() }
                .setNegativeButton("Hayır", null).show()
        }

        btnExport.setOnClickListener {
            if (gs1List.isEmpty() && otherList.isEmpty()) {
                Toast.makeText(this, "Liste boş!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (secilenDepo.isEmpty()) {
                Toast.makeText(this, "Önce depo seçin!", Toast.LENGTH_SHORT).show()
                showDepoDialog(); return@setOnClickListener
            }
            showExportDialog()
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            val item = getDisplayItem(position)
            AlertDialog.Builder(this)
                .setTitle("Sil")
                .setMessage("Bu barkodu kaldır?\n\n$item")
                .setPositiveButton("Sil") { _, _ ->
                    removeItemAt(position)
                    saveToPrefs()
                    updateUI()
                }
                .setNegativeButton("İptal", null).show()
            true
        }

        updateUI()

        if (secilenDepo.isEmpty()) {
            Handler(Looper.getMainLooper()).postDelayed({ showDepoDialog() }, 400)
        }
    }

    // ── YARIM SAYIM ──────────────────────────────────────────────────
    private fun checkResumeSayim() {
        val savedGs1  = prefs.getStringSet("gs1_indexed", null)
        val savedOther = prefs.getStringSet("other_indexed", null)
        val savedDepo  = prefs.getString("depo", "") ?: ""

        if (!savedGs1.isNullOrEmpty() || !savedOther.isNullOrEmpty()) {
            val toplam = (savedGs1?.size ?: 0) + (savedOther?.size ?: 0)
            val savedTarih = prefs.getString("tarih", "") ?: ""
            AlertDialog.Builder(this)
                .setTitle("Yarım Sayım Bulundu")
                .setMessage("$DISPLAY_PREFIX$savedDepo\nTarih: $savedTarih\n$toplam barkod okunmuş.\n\nDevam edilsin mi?")
                .setPositiveButton("Devam Et") { _, _ ->
                    savedGs1?.sortedBy { it.substringBefore("|").toIntOrNull() ?: 0 }
                        ?.forEach { gs1List.add(it.substringAfter("|")) }
                    savedOther?.sortedBy { it.substringBefore("|").toIntOrNull() ?: 0 }
                        ?.forEach { otherList.add(it.substringAfter("|")) }
                    secilenDepo  = savedDepo
                    kullaniciAdi = prefs.getString("kullanici", "") ?: ""
                    kullanimYeri = prefs.getString("kullanim", "") ?: ""
                    sayimTarihi  = prefs.getString("tarih", "") ?: ""
                    adapter.notifyDataSetChanged()
                    updateUI()
                }
                .setNegativeButton("Sil, Yeniden Başla") { _, _ -> clearPrefs() }
                .setCancelable(false)
                .show()
        }
    }

    // ── DEPO DIALOG ──────────────────────────────────────────────────
    private fun showDepoDialog() {
        AlertDialog.Builder(this)
            .setTitle("Depo Seç")
            .setItems(arrayOf("📷  QR Kod Okut", "✏️  Elle Gir")) { _, which ->
                when (which) {
                    0 -> {
                        isDepoScanMode = true
                        if (isHoneywell) {
                            Toast.makeText(this, "Tetik tuşuna basarak depo QR kodunu okutun", Toast.LENGTH_LONG).show()
                        } else {
                            openCamera(depoMode = true)
                            Toast.makeText(this, "Depo QR kodunu kameraya gösterin", Toast.LENGTH_LONG).show()
                        }
                    }
                    1 -> showManualDepoInput()
                }
            }.show()
    }

    private fun showManualDepoInput() {
        val et = EditText(this).apply {
            hint = "Depo no girin (örn: 454)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(40, 20, 40, 20)
        }
        AlertDialog.Builder(this)
            .setTitle("Depo Numarası Girin")
            .setMessage("Kısa numara (419, 422, 425, 428, 454, 457) veya tam kod")
            .setView(et)
            .setPositiveButton("Tamam") { _, _ ->
                val input = et.text.toString().trim()
                val fullCode = shortCodeMap[input] ?: input
                if (depoList.contains(fullCode)) {
                    secilenDepo = fullCode
                    updateUI()
                    Toast.makeText(this, "✓ $DISPLAY_PREFIX$secilenDepo", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Geçersiz depo numarası: $input", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("İptal", null).show()
    }

    // ── BARKOD İŞLEME ────────────────────────────────────────────────
    private fun processBarcode(barcode: String) {
        // GS karakterini KORUYARAK sadece baştaki/sondaki boşlukları temizle
        val raw = barcode.trim()

        // Depo QR kontrolü (GS olmaz, direkt string)
        val rawNoGs = raw.replace(GS.toString(), "")
        if (rawNoGs.startsWith(QR_PREFIX)) {
            val depoKod = rawNoGs.removePrefix(QR_PREFIX)
            runOnUiThread {
                secilenDepo = depoKod
                isDepoScanMode = false
                closeCamera()
                updateUI()
                Toast.makeText(this, "✓ $DISPLAY_PREFIX$secilenDepo", Toast.LENGTH_SHORT).show()
            }
            return
        }

        if (isDepoScanMode) return

        val formatted = formatToGS1(raw)

        val isGs1 = formatted.startsWith("(90)") || formatted.contains("(250)")
        val allItems = gs1List + otherList

        if (allItems.contains(formatted)) {
            runOnUiThread {
                beepError()
                flashStatus("#F44336")
                showDuplicate(formatted)
            }
            return
        }

        runOnUiThread {
            if (isGs1) gs1List.add(0, formatted)
            else otherList.add(formatted)
            adapter.notifyDataSetChanged()
            tvLastScan.text = formatted
            flashStatus("#4CAF50")
            beepSuccess()
            saveToPrefs()
            updateUI()
        }
    }

    // ── GS1 FORMATTER ────────────────────────────────────────────────
    /**
     * Ham barkodu GS1 formatına çevirir.
     * 3 durum:
     * 1. Parantez içeriyorsa → zaten formatlanmış, dokunma
     * 2. GS karakteri içeriyorsa → CK65 segmentli format, parseSingleAI ile parse et
     * 3. GS yoksa → tek string, parseAllInOne ile parse et
     */
    private fun formatToGS1(raw: String): String {
        // 1. Zaten formatlanmış (parantezli) veya INSICC
        if (raw.contains('(') || raw.startsWith("INSI")) return raw

        // 2. GS segmentli — CK65 her AI'ı ayrı segment olarak gönderir
        if (GS in raw) {
            val segs = raw.split(GS)
            val sb = StringBuilder()
            segs.forEachIndexed { idx, seg ->
                val s = seg.trim()
                if (s.isEmpty()) return@forEachIndexed
                if (idx == 0) {
                    // İlk segment: "90TR022" → "(90)TR022"
                    if (s.length >= 7 && s[0].isDigit() && s[1].isDigit()) {
                        sb.append("(${s.substring(0, 2)})${s.substring(2, 7)}")
                    } else sb.append(s)
                } else {
                    sb.append(parseSingleAI(s))
                }
            }
            return sb.toString()
        }

        // 3. GS yok — tek uzun string
        return parseAllInOne(raw)
    }

    /**
     * Tek GS segmentini parse eder.
     * Her segment tam olarak bir AI içerir.
     */
    private fun parseSingleAI(seg: String): String {
        val n = seg.length
        return when {
            seg.startsWith("250") && n >= 14  -> "(250)${seg.substring(3, 14)}"
            seg.startsWith("240") && n >= 6   -> "(240)${seg.substring(3, 6)}"
            seg.startsWith("3100") && n >= 10 -> "(3100)${seg.substring(4, 10)}"
            seg.startsWith("3101") && n >= 10 -> "(3101)${seg.substring(4, 10)}"
            seg.startsWith("3103") && n >= 10 -> "(3103)${seg.substring(4, 10)}"
            seg.startsWith("3301") && n >= 10 -> "(3301)${seg.substring(4, 10)}"
            seg.startsWith("20")   && n >= 4  -> "(20)${seg.substring(2, 4)}"
            seg.startsWith("37")   && n >= 4  -> "(37)${seg.substring(2, 4)}"
            seg.startsWith("30")   && n >= 2  -> "(30)${seg.substring(2)}"
            else -> seg
        }
    }

    /**
     * GS olmayan tek uzun string'i parse eder.
     * Örnek: "90TR022250470995506812400012003304037403101000200330100020"
     */
    private fun parseAllInOne(raw: String): String {
        val sb = StringBuilder()
        var i = 0
        val n = raw.length
        while (i < n) {
            val r = raw.substring(i)
            when {
                i == 0 && n >= 7 && raw[0].isDigit() && raw[1].isDigit() -> {
                    sb.append("(${raw.substring(0, 2)})${raw.substring(2, 7)}"); i = 7
                }
                r.startsWith("250") && i + 14 <= n -> {
                    sb.append("(250)${raw.substring(i + 3, i + 14)}"); i += 14
                }
                r.startsWith("240") && i + 6 <= n -> {
                    sb.append("(240)${raw.substring(i + 3, i + 6)}"); i += 6
                }
                r.startsWith("3100") && i + 10 <= n -> {
                    sb.append("(3100)${raw.substring(i + 4, i + 10)}"); i += 10
                }
                r.startsWith("3103") && i + 10 <= n -> {
                    sb.append("(3103)${raw.substring(i + 4, i + 10)}"); i += 10
                }
                r.startsWith("3101") && i + 10 <= n -> {
                    sb.append("(3101)${raw.substring(i + 4, i + 10)}"); i += 10
                }
                r.startsWith("3301") && i + 10 <= n -> {
                    sb.append("(3301)${raw.substring(i + 4, i + 10)}"); i += 10
                }
                r.startsWith("20") && i + 4 <= n -> {
                    sb.append("(20)${raw.substring(i + 2, i + 4)}"); i += 4
                }
                r.startsWith("37") && i + 4 <= n -> {
                    sb.append("(37)${raw.substring(i + 2, i + 4)}"); i += 4
                }
                r.startsWith("30") && i + 2 <= n -> {
                    sb.append("(30)"); i += 2
                    val stop = listOf("37", "310", "330", "240", "20", "30")
                    var e = i
                    while (e < n && stop.none { raw.startsWith(it, e) }) e++
                    sb.append(raw.substring(i, e)); i = e
                }
                else -> break
            }
        }
        return sb.toString()
    }

    // ── EXPORT ───────────────────────────────────────────────────────
    private fun showExportDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 30, 60, 20)
        }
        fun label(text: String) = TextView(this).apply {
            this.text = text; textSize = 12f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, 14, 0, 4)
        }
        val etKullanici = EditText(this).apply {
            hint = "Kullanıcı Adı"; setText(kullaniciAdi)
        }
        val etKullanim = EditText(this).apply {
            hint = "Kullanım Yeri (örn: T3 Tüneli)"; setText(kullanimYeri)
        }
        layout.addView(TextView(this).apply {
            text = "$DISPLAY_PREFIX$secilenDepo"
            textSize = 14f; setTextColor(Color.parseColor("#4CAF50"))
            setPadding(0, 0, 0, 12)
        })
        layout.addView(label("Kullanıcı Adı"))
        layout.addView(etKullanici)
        layout.addView(label("Kullanım Yeri"))
        layout.addView(etKullanim)

        AlertDialog.Builder(this)
            .setTitle("Dışa Aktarma Bilgileri")
            .setView(layout)
            .setPositiveButton("AKTAR") { _, _ ->
                kullaniciAdi = etKullanici.text.toString().trim().ifEmpty { "-" }
                kullanimYeri = etKullanim.text.toString().trim().ifEmpty { "-" }
                val tarih = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                val fileName = "özaltın_${secilenDepo}_$tarih.txt"
                exportLauncher.launch(fileName)
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun saveToFile(uri: Uri) {
        try {
            val out: OutputStream? = contentResolver.openOutputStream(uri)
            val sb = StringBuilder()
            val tarihGoster = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
            val toplam = gs1List.size + otherList.size

            sb.appendLine("Depo: $DISPLAY_PREFIX$secilenDepo")
            sb.appendLine("Kullanici: $kullaniciAdi")
            sb.appendLine("Kullanim Yeri: $kullanimYeri")
            sb.appendLine("Tarih: $tarihGoster")
            sb.appendLine("Adet: $toplam")
            sb.appendLine()
            sb.appendLine("Barcode")
            gs1List.reversed().forEach { sb.appendLine(it) }
            otherList.forEach { sb.appendLine(it) }

            out?.write(sb.toString().toByteArray(Charsets.UTF_8))
            out?.close()
            Toast.makeText(this, "✓ $toplam barkod aktarıldı", Toast.LENGTH_LONG).show()

            AlertDialog.Builder(this)
                .setTitle("Aktarım Tamam")
                .setMessage("$toplam barkod aktarıldı.\nListe temizlensin mi?")
                .setPositiveButton("Evet, Temizle") { _, _ -> clearAll() }
                .setNegativeButton("Hayır", null).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── PREFS ─────────────────────────────────────────────────────────
    private fun saveToPrefs() {
        prefs.edit().apply {
            putStringSet("gs1_indexed", gs1List.mapIndexed { i, v -> "$i|$v" }.toSet())
            putStringSet("other_indexed", otherList.mapIndexed { i, v -> "$i|$v" }.toSet())
            putString("depo", secilenDepo)
            putString("kullanici", kullaniciAdi)
            putString("kullanim", kullanimYeri)
            putString("tarih", sayimTarihi.ifEmpty {
                SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
                    .also { sayimTarihi = it }
            })
            apply()
        }
    }

    private fun clearPrefs() = prefs.edit().clear().apply()

    private fun clearAll() {
        gs1List.clear(); otherList.clear()
        secilenDepo = ""; kullaniciAdi = ""; kullanimYeri = ""; sayimTarihi = ""
        clearPrefs()
        adapter.notifyDataSetChanged()
        updateUI()
        tvLastScan.text = "Bekleniyor..."
        flashStatus("#555555")
    }

    // ── UI ───────────────────────────────────────────────────────────
    private fun updateUI() {
        val toplam = gs1List.size + otherList.size
        tvCount.text = toplam.toString()
        if (secilenDepo.isNotEmpty()) {
            tvDepoInfo.text = "$DISPLAY_PREFIX$secilenDepo"
            tvDepoInfo.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            tvDepoInfo.text = "Depo seçilmedi"
            tvDepoInfo.setTextColor(Color.parseColor("#F44336"))
        }
    }

    private fun getDisplayItem(position: Int): String =
        if (position < gs1List.size) gs1List[position]
        else otherList[position - gs1List.size]

    private fun removeItemAt(position: Int) {
        if (position < gs1List.size) gs1List.removeAt(position)
        else otherList.removeAt(position - gs1List.size)
        adapter.notifyDataSetChanged()
    }

    private fun flashStatus(color: String) {
        statusBar.setBackgroundColor(Color.parseColor(color))
        Handler(Looper.getMainLooper()).postDelayed({
            statusBar.setBackgroundColor(Color.parseColor("#4CAF50"))
        }, 600)
    }

    private fun showDuplicate(barcode: String) {
        runOnUiThread {
            val d = AlertDialog.Builder(this)
                .setTitle("⚠ Mükerrer Okuma!")
                .setMessage("Bu barkod zaten listede:\n\n$barcode")
                .create()
            d.show()
            Handler(Looper.getMainLooper()).postDelayed({ if (d.isShowing) d.dismiss() }, 2500)
        }
    }

    // ── SES & TİTREŞİM ───────────────────────────────────────────────
    private fun beepSuccess() {
        try { toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 80) } catch (_: Exception) {}
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        else v.vibrate(60)
    }

    private fun beepError() {
        try { toneGen.startTone(ToneGenerator.TONE_PROP_NACK, 300) } catch (_: Exception) {}
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
        else v.vibrate(500)
    }

    // ── KAMERA ───────────────────────────────────────────────────────
    private fun openCamera(depoMode: Boolean) {
        isDepoScanMode = depoMode
        viewFinder.visibility = View.VISIBLE
        btnCamera.text = "📷 Kapat"
        isCameraOpen = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermLauncher.launch(Manifest.permission.CAMERA)
    }

    @OptIn(ExperimentalGetImage::class)
    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val cp = fut.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            val scanner = BarcodeScanning.getClient()
            analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
                val mediaImage = proxy.image
                if (mediaImage != null) {
                    val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                    scanner.process(image)
                        .addOnSuccessListener { codes ->
                            codes.forEach { bc ->
                                val now = System.currentTimeMillis()
                                val delay = if (isDepoScanMode) 500L else 1500L
                                if (now - lastCameraScanTime > delay) {
                                    bc.rawValue?.let { processBarcode(it); lastCameraScanTime = now }
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                } else proxy.close()
            }
            try {
                cp.unbindAll()
                cp.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun closeCamera() {
        ProcessCameraProvider.getInstance(this).addListener({
            ProcessCameraProvider.getInstance(this).get().unbindAll()
            runOnUiThread {
                viewFinder.visibility = View.GONE
                btnCamera.text = "📷 Kamera"
                isCameraOpen = false
                isDepoScanMode = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ── RECEIVER ─────────────────────────────────────────────────────
    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction("com.honeywell.intent.action.SCAN")
            addAction("com.honeywell.action.BARCODE_DATA")
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(scanReceiver, filter, Context.RECEIVER_EXPORTED)
        else registerReceiver(scanReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try { toneGen.release() } catch (_: Exception) {}
    }

    // ── ADAPTER ──────────────────────────────────────────────────────
    inner class BarcodeListAdapter(
        ctx: Context,
        private val gs1: List<String>,
        private val other: List<String>
    ) : BaseAdapter() {

        override fun getCount() = gs1.size + other.size
        override fun getItem(position: Int) =
            if (position < gs1.size) gs1[position] else other[position - gs1.size]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@MainActivity
            val row = convertView as? LinearLayout ?: LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(12, 8, 12, 8)
            }
            row.removeAllViews()

            val isOther = position >= gs1.size
            val item = getItem(position)

            val tvNr = TextView(ctx).apply {
                text = "${position + 1}"
                textSize = 10f
                setTextColor(Color.parseColor("#555555"))
                minWidth = 52
                setPadding(0, 0, 8, 0)
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val tvBarcode = TextView(ctx).apply {
                text = if (isOther) "⚡ $item" else item
                textSize = 11f
                setTextColor(if (isOther) Color.parseColor("#FF9800") else Color.parseColor("#CCCCCC"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tvNr)
            row.addView(tvBarcode)
            row.setBackgroundColor(
                when {
                    isOther -> Color.parseColor("#1A1200")
                    position % 2 == 0 -> Color.parseColor("#0D0D0D")
                    else -> Color.parseColor("#111111")
                }
            )
            return row
        }
    }
}
